///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Modified for CS-330-Computational Graphics and Visualization, [August 3rd 2025]
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
    // Constructor
    ViewManager(ShaderManager* pShaderManager);
    // Destructor
    ~ViewManager();

    // Mouse position callback for mouse interaction with the 3D scene
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
    // Mouse scroll callback for adjusting camera zoom
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);
    // Framebuffer size callback for window resizing
    static void Framebuffer_Size_Callback(GLFWwindow* window, int width, int height);

private:
    // Pointer to shader manager object
    ShaderManager* m_pShaderManager;
    // Active OpenGL display window
    GLFWwindow* m_pWindow;

    // Process keyboard events for interaction with the 3D scene
    void ProcessKeyboardEvents();

public:
    // Create the initial OpenGL display window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Prepare the conversion from 3D object display to 2D scene display
    void PrepareSceneView();

    // Get the current width of the window
    int getWidth() const;
    // Get the current height of the window
    int getHeight() const;
    // Set new dimensions for the window
    void setDimensions(int width, int height);
    glm::vec3 GetCameraPosition() const;
    void ProcessMouseScroll(double yoffset);
};
