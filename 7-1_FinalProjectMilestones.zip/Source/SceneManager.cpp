///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/*
 *  SceneManager()
 *
 *  The constructor for the class
 */
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_viewPosition = glm::vec3(0.0f, 5.0f, 10.0f);
}

/*
 *  ~SceneManager()
 *
 *  The destructor for the class
 */
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	SceneManager::Cleanup();
}

/*
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 */
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/*
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 */
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/*
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 */
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

/*
 *  Cleanup()
 *
 *  This method cleans up all resources
 */
void SceneManager::Cleanup()
{
	DestroyGLTextures();
	m_lights.clear();
	m_objectMaterials.clear();
}

/*
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 */
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/*
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 */
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/*
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 */
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/*
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 */
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/*
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 */
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/*
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 */
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/*
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 */
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/*
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 */
void SceneManager::SetShaderMaterial(
	glm::vec3 diffuseColor,
	glm::vec3 specularColor,
	float shininess)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec3Value("material.diffuse", diffuseColor);
		m_pShaderManager->setVec3Value("material.specular", specularColor);
		m_pShaderManager->setFloatValue("material.shininess", shininess);
	}
}

/*
 *  SetShaderMaterial()
 *
 *  Overload for default material
 */
void SceneManager::SetShaderMaterial()
{
	SetShaderMaterial(
		glm::vec3(0.5f, 0.5f, 0.5f), // Default diffuse
		glm::vec3(0.5f, 0.5f, 0.5f), // Default specular
		32.0f);                      // Default shininess
}

/*
 *  SetupLighting()
 *
 *  This method sets up the lighting for the scene
 */
void SceneManager::SetupLighting()
{
	// Clear any existing lights
	m_lights.clear();

	// Add a directional light (like sunlight)
	LIGHT mainLight;
	mainLight.tag = "mainLight";
	mainLight.type = 0; // Directional light
	mainLight.direction = glm::vec3(-0.5f, -1.0f, -0.5f); // Direction from top-right
	mainLight.color = glm::vec3(1.0f, 1.0f, 0.9f); // Slightly warm white light
	mainLight.intensity = 0.8f;
	mainLight.cutOff = 0.0f;
	m_lights.push_back(mainLight);

	// Add a point light to fill in shadows
	LIGHT fillLight;
	fillLight.tag = "fillLight";
	fillLight.type = 1; // Point light
	fillLight.position = glm::vec3(5.0f, 5.0f, 5.0f);
	fillLight.color = glm::vec3(0.8f, 0.8f, 1.0f); // Slightly blue fill light
	fillLight.intensity = 0.4f;
	fillLight.cutOff = 0.0f;
	m_lights.push_back(fillLight);
}

/*
 *  SetupLightsInShader()
 *
 *  This method sets up the lights in the shader
 */
void SceneManager::SetupLightsInShader()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	// Set the view position (camera position)
	m_pShaderManager->setVec3Value("viewPos", m_viewPosition);

	// Set the number of lights
	m_pShaderManager->setIntValue("numLights", (int)m_lights.size());

	// Set up each light in the shader
	for (int i = 0; i < m_lights.size(); i++)
	{
		std::string lightIndex = "lights[" + std::to_string(i) + "]";

		m_pShaderManager->setIntValue(lightIndex + ".type", m_lights[i].type);
		m_pShaderManager->setVec3Value(lightIndex + ".position", m_lights[i].position);
		m_pShaderManager->setVec3Value(lightIndex + ".direction", m_lights[i].direction);
		m_pShaderManager->setVec3Value(lightIndex + ".color", m_lights[i].color);
		m_pShaderManager->setFloatValue(lightIndex + ".intensity", m_lights[i].intensity);
		m_pShaderManager->setFloatValue(lightIndex + ".cutOff", m_lights[i].cutOff);
	}
}

/*
 *  UpdateViewPosition()
 *
 *  This method updates the camera position for lighting calculations
 */
void SceneManager::UpdateViewPosition(glm::vec3 cameraPosition)
{
	m_viewPosition = cameraPosition;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec3Value("viewPos", m_viewPosition);
	}
}

//
/* STUDENTS CAN MODIFY the code in the methods BELOW for  */
/* preparing and rendering their own 3D replicated scenes.*/
/* Please refer to the code in the OpenGL sample project  */
/* for assistance.                                        */
//

/*
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 */
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// Loading necessary meshes
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh(); 
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();


	//load texture for objects
	CreateGLTexture("textures/table.jpg", "table");  
	CreateGLTexture("textures/pen_tip.jpg", "pen_tip");
	CreateGLTexture("textures/pen_body.jpg", "pen_body");
	CreateGLTexture("textures/iphone_screen.jpg", "iphone_screen");
	CreateGLTexture("textures/mouse.jpg", "mouse");
	CreateGLTexture("textures/keyboard_keys.jpg", "keyboard_keys");
	CreateGLTexture("textures/coffee_cup.jpg", "coffee_cup");
	CreateGLTexture("textures/coffee_handle.jpg", "coffee_handle");
	CreateGLTexture("textures/notebook_cover.jpg", "notebook_cover");
	CreateGLTexture("textures/eight_ball.jpg", "eight_ball");


	BindGLTextures();

	// Add lighting setup
	SetupLighting();
}

/*
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 */
void SceneManager::RenderScene()
{
	// Set up lighting in the shader
	SetupLightsInShader();

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/* Set needed transformations before drawing the basic mesh.  */
	/* This same ordering of code should be used for transforming */
	/* and drawing all the basic 3D shapes.						*/
	//
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	SetShaderTexture("table"); // Apply texture
	SetTextureUVScale(2.0, 2.0); // Set scale

	// Set material properties for the table (wood)
	SetShaderMaterial(
		glm::vec3(0.6f, 0.5f, 0.4f), // Diffuse color (brownish)
		glm::vec3(0.3f, 0.3f, 0.3f), // Specular color
		16.0f);                      // Shininess (wood is not very shiny)

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/**/

	// Pen Body (Cylinder)
	scaleXYZ = glm::vec3(0.1f, 2.0f, 0.1f); // Radius, Height, Radius
	XrotationDegrees = 90.0f; // Rotate to stand upright
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f; // No rotation around Z for simplicity
	// Adjust position so the pen touches the table
	positionXYZ = glm::vec3(-5.0f, 0.3f, 4.5f); // Position left, cylinder at table
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("pen_body"); // Apply texture
	SetTextureUVScale(1.0, 1.0); // Set scale

	// Set material properties for the pen body (plastic)
	SetShaderMaterial(
		glm::vec3(0.8f, 0.8f, 0.8f), // Diffuse color
		glm::vec3(0.5f, 0.5f, 0.5f), // Specular color
		64.0f);                      // Shininess (plastic is somewhat shiny)

	m_basicMeshes->DrawCylinderMesh();

	// Pen Tip (Cone)
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.1f); // Radius, Height, Radius
	XrotationDegrees = 270.0f; // Rotate to align with cylinder
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 180.0f; // Rotate 180 degrees around Z to flip the cone
	// Position the tip at the bottom of the cylinder, touching the table
	positionXYZ = glm::vec3(-5.0f, 0.3f, 6.5f); // Position at the table level
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("pen_tip"); // Apply texture
	SetTextureUVScale(1.0, 1.0); // Set scale

	// Set material properties for the pen tip (metal)
	SetShaderMaterial(
		glm::vec3(0.3f, 0.3f, 0.3f), // Diffuse color (dark gray)
		glm::vec3(0.8f, 0.8f, 0.8f), // Specular color (high reflectivity)
		128.0f);                     // Shininess (metal is very shiny)

	m_basicMeshes->DrawConeMesh();
	//iPhone
	scaleXYZ = glm::vec3(1.1f, 0.05f, 2.5f); // Thin cuboid, wider face up
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-8.0f, 0.06f, 5.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("iphone_screen");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(glm::vec3(0.1f), glm::vec3(0.8f), 32.0f);
	m_basicMeshes->DrawBoxMesh();


	//Keyboard
	scaleXYZ = glm::vec3(5.5f, 0.5f, 2.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.15f, -4.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("keyboard_keys");
	SetTextureUVScale(1.0f, 1.0f); // Tiling keys texture to look realistic
	SetShaderMaterial(glm::vec3(0.9f), glm::vec3(0.3f), 8.0f);
	m_basicMeshes->DrawPlaneMesh();

	//Mouse
	scaleXYZ = glm::vec3(1.0f, 0.2f, 1.5f);
	positionXYZ = glm::vec3(3.5f, 0.05f, 4.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1, 1, 1, 1);
	SetShaderTexture("mouse");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(glm::vec3(0.9f, 0.9f, 0.9f), glm::vec3(0.4f), 32.0f);
	m_basicMeshes->DrawBoxMesh();


// Cup Body (Cylinder)
	scaleXYZ = glm::vec3(0.8f, 1.2f, 0.8f);
	XrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(12.0f, 0.01f, -5.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("coffee_cup");
	SetTextureUVScale(5.0f, 3.0f);
	SetShaderMaterial(glm::vec3(0.7f, 0.3f, 0.1f), glm::vec3(0.5f), 32.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Cup Handle (Torus)
	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);
	XrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(12.8f, 0.6f, -5.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, ZrotationDegrees, positionXYZ);
	SetShaderTexture("coffee_handle");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(glm::vec3(0.3f), glm::vec3(0.4f), 16.0f);
	m_basicMeshes->DrawTorusMesh();


// Notebook
	scaleXYZ = glm::vec3(5.0f, 0.3f, 7.0f);
	positionXYZ = glm::vec3(-1.0f, 0.05f, 5.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("notebook_cover");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(glm::vec3(0.8f, 0.8f, 0.9f), glm::vec3(0.3f), 8.0f);
	m_basicMeshes->DrawBoxMesh();

	// 8 Ball
	scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
	positionXYZ = glm::vec3(-14.0f, 1.0f, -6.0f); 
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("eight_ball");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(glm::vec3(0.1f), glm::vec3(0.9f), 512.0f); // Very shiny black surface
	m_basicMeshes->DrawSphereMesh();


}


